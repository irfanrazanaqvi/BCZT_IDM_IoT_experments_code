"""
Module handling the file naming operation (relative -> absolute, etc)
"""

import logging
import os.path
import platform
import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from crytic_compile.platform.exceptions import InvalidCompilation

# Cycle dependency
if TYPE_CHECKING:
    from crytic_compile import CryticCompile

LOGGER = logging.getLogger("CryticCompile")


@dataclass
class Filename:
    """Path metadata for each file in the compilation unit"""

    def __init__(self, absolute: str, used: str, relative: str, short: str):
        self.absolute = absolute
        self.used = used
        self.relative = relative
        self.short = short

    def __hash__(self) -> int:
        return hash(self.relative)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Filename):
            return NotImplemented
        return self.relative == other.relative

    def __repr__(self) -> str:
        return f"Filename(absolute={self.absolute}, used={self.used}, relative={self.relative}, short={self.short}))"


def extract_name(name: str) -> str:
    """Convert '/path:Contract' to Contract

    Args:
        name (str): name to convert

    Returns:
        str: extracted contract name
    """
    return name[name.rfind(":") + 1 :]


def extract_filename(name: str) -> str:
    """Convert '/path:Contract' to /path

    Args:
        name (str): name to convert

    Returns:
        str: extracted filename
    """
    if ":" not in name:
        return name
    return name[: name.rfind(":")]


def combine_filename_name(filename: str, name: str) -> str:
    """Combine the filename with the contract name

    Args:
        filename (str): filename
        name (str): contract name

    Returns:
        str: Combined names
    """
    return filename + ":" + name


def _verify_filename_existence(filename: Path, cwd: Path) -> Path:
    """
    Check if the filename exist. If it does not, try multiple heuristics to find the right filename:
    - Look for contracts/FILENAME
    - Look for node_modules/FILENAME
    - Look for node_modules/FILENAME in all the parents directories


    Args:
        filename (Path): filename to check
        cwd (Path): directory

    Raises:
        InvalidCompilation: if the filename is not found

    Returns:
        Path: the filename
    """

    if filename.exists():
        return filename

    if cwd.joinpath(Path("contracts"), filename).exists():
        filename = cwd.joinpath("contracts", filename)
    elif cwd.joinpath(filename).exists():
        filename = cwd.joinpath(filename)
    # how node.js loads dependencies from node_modules:
    # https://nodejs.org/api/modules.html#loading-from-node_modules-folders
    elif cwd.joinpath(Path("node_modules"), filename).exists():
        filename = cwd.joinpath("node_modules", filename)
    else:
        for parent in cwd.parents:
            if parent.joinpath(Path("node_modules"), filename).exists():
                filename = parent.joinpath(Path("node_modules"), filename)
                break

    if not filename.exists():
        raise InvalidCompilation(_unknown_file_message(filename, cwd))

    return filename


def _unknown_file_message(filename: Path, cwd: Path) -> str:
    """Build an actionable error message for a path that could not be resolved.

    Includes hints to verify the path exists and, when the import resembles an
    npm/yarn dependency (e.g. ``@openzeppelin/...``), to install project
    dependencies.

    Args:
        filename (Path): the unresolved filename
        cwd (Path): the working directory used during resolution

    Returns:
        str: a multi-line error message
    """
    lines = [
        f"Unknown file: {filename}",
        f"  - Verify the path exists (e.g. `ls {filename}`).",
    ]
    if _looks_like_npm_import(filename):
        lines.append(
            f"  - If this is an npm/yarn dependency, install project "
            f"dependencies first (e.g. `npm install` or `yarn install` in `{cwd}`)."
        )
    return "\n".join(lines)


def _looks_like_npm_import(filename: Path) -> bool:
    """Heuristic: is ``filename`` likely an npm/yarn dependency import?

    Treats scoped (``@org/pkg/...``) and bare-name (``pkg/...``) paths with
    multiple segments as package imports. Excludes absolute paths, paths that
    start with ``.`` or ``..``, and the common Solidity project source roots
    (``contracts``, ``src``, ``lib``, ``test``, ``script``).

    Args:
        filename (Path): filename to classify

    Returns:
        bool: True if the path resembles a package import
    """
    if filename.is_absolute():
        return False
    parts = filename.parts
    if len(parts) < 2:
        return False
    first = parts[0]
    if first.startswith("."):
        return False
    if first in {"contracts", "src", "lib", "test", "tests", "script"}:
        return False
    # @scope/package or bare package name (no extension/dot in first segment)
    return first.startswith("@") or "." not in first


def convert_filename(
    used_filename: str | Path,
    relative_to_short: Callable[[Path], Path],
    crytic_compile: "CryticCompile",
    working_dir: str | Path | None = None,
) -> Filename:
    """Convert a filename to CryticCompile Filename object.
    The used_filename can be absolute, relative, or missing node_modules/contracts directory

    Args:
        used_filename (Union[str, Path]): Used filename
        relative_to_short (Callable[[Path], Path]): Callback to translate the relative to short
        crytic_compile (CryticCompile): Associated CryticCompile object
        working_dir (Optional[Union[str, Path]], optional): Working directory. Defaults to None.

    Returns:
        Filename: Filename converted
    """
    filename_txt = used_filename
    if platform.system() == "Windows":
        elements = list(Path(filename_txt).parts)
        if elements[0] == "/" or elements[0] == "\\":
            elements = elements[1:]  # remove '/'
            elements[0] = elements[0] + ":/"  # add :/
        filename = Path(*elements)
    else:
        filename = Path(filename_txt)

    # cwd points to the directory to be used
    if working_dir is None:
        cwd = Path.cwd()
    else:
        working_dir = Path(working_dir)
        if working_dir.is_absolute():
            cwd = working_dir
        else:
            cwd = Path.cwd().joinpath(Path(working_dir)).resolve()

    if crytic_compile.package_name:
        try:
            filename = filename.relative_to(Path(crytic_compile.package_name))
        except ValueError:
            pass

    filename = _verify_filename_existence(filename, cwd)

    absolute = Path(os.path.abspath(filename))

    # This returns original path if *path* and *start* are on different drives (for Windows platform).
    try:
        relative = Path(os.path.relpath(filename, Path.cwd()))
    except ValueError:
        relative = Path(filename)

    # Build the short path
    try:
        if cwd.is_absolute():
            short = absolute.relative_to(cwd)
        else:
            short = relative.relative_to(cwd)
    except ValueError:
        short = relative
    except RuntimeError:
        short = relative

    short = relative_to_short(short)
    # Starting with v0.8.8 (https://github.com/ethereum/solidity/pull/11545), solc normalizes the paths to not include the drive on Windows,
    # so it's important we use posix path here to avoid issues with the path comparison.
    return Filename(
        absolute=absolute.as_posix(),
        relative=relative.as_posix(),
        short=short.as_posix(),
        used=Path(used_filename).as_posix(),
    )


def process_hardhat_v3_filename(filename: str) -> str:
    """Process hardhat v3 filename format
    If the filename is in v3 format, it will be converted to v2 format.

    Args:
        filename (str): filename to convert

    Returns:
        str: converted filename
    """
    # CASE 1 — npm/... → ...
    hh3_npm_path = re.match(r"npm/(.+?)@[^/]+/(.+)", filename)
    if hh3_npm_path:
        package = hh3_npm_path.group(1)
        rest = hh3_npm_path.group(2)
        filename = f"{package}/{rest}"

    # CASE 2 — project/contracts/... → contracts/...
    hh3_contracts_path = re.match(r"project/contracts/(.+)", filename)
    if hh3_contracts_path:
        filename = f"contracts/{hh3_contracts_path.group(1)}"
    return filename
