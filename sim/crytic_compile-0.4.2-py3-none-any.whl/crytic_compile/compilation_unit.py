"""
Module handling the compilation unit
Each compilation unit represents a call to the compiler
Each compilation unit has one or more source units associated with it
At least one compilation unit exists for each version of solc used
    Maybe more dependending on the framework used (hardhat/foundry/etc)
"""

import re
import uuid
from collections import defaultdict
from typing import TYPE_CHECKING, cast

from crytic_compile.compiler.compiler import CompilerVersion
from crytic_compile.source_unit import SourceUnit
from crytic_compile.utils.naming import Filename

# Cycle dependency
if TYPE_CHECKING:
    from crytic_compile import CryticCompile


class CompilationUnit:
    """CompilationUnit class"""

    def __init__(self, crytic_compile: "CryticCompile", unique_id: str):
        """Init the object

        Args:
            crytic_compile (CryticCompile): Associated CryticCompile object
            unique_id (str): Unique ID used to identify the compilation unit
        """

        # mapping from filename to contract name
        self._filename_to_contracts: dict[Filename, set[str]] = defaultdict(set)

        # mapping from filename to source unit
        self._source_units: dict[Filename, SourceUnit] = {}

        # set containing all the filenames of this compilation unit
        self._filenames: list[Filename] = []

        # mapping from source ID to filename (for Foundry/Hardhat source map compatibility)
        # When set, this takes precedence over _filenames for export ordering
        self._source_id_to_filename: dict[int, Filename] = {}

        # mapping from absolute/relative/used to filename
        self._filenames_lookup: dict[str, Filename] | None = None

        # compiler.compiler
        self._compiler_version: CompilerVersion = CompilerVersion(
            compiler="N/A", version="N/A", optimized=False, via_ir=False
        )

        # if the compilation unit comes from etherscan-like service and is a proxy,
        # store the implementation addresses (e.g., diamond proxies can have multiple)
        self._implementation_addresses: set[str] = set()

        self._crytic_compile: CryticCompile = crytic_compile

        if unique_id == ".":
            unique_id = str(uuid.uuid4())

        crytic_compile.compilation_units[unique_id] = self

        self._unique_id = unique_id

    @property
    def unique_id(self) -> str:
        """Return the compilation unit ID

        Returns:
            str: Compilation unit unique ID
        """
        return self._unique_id

    @property
    def crytic_compile(self) -> "CryticCompile":
        """Return the CryticCompile object

        Returns:
            CryticCompile: Associated CryticCompile object
        """
        return self._crytic_compile

    @property
    def source_units(self) -> dict[Filename, SourceUnit]:
        """
        Return the dict of the source units

        Returns:
            Dict[Filename, SourceUnit]: the source units
        """
        return self._source_units

    def source_unit(self, filename: Filename) -> SourceUnit:
        """
        Return the source unit associated to the filename.
        The source unit must have been created by create_source_units

        Args:
            filename: filename of the source unit

        Returns:
            SourceUnit: the source unit
        """
        return self._source_units[filename]

    @property
    def asts(self) -> dict[str, dict]:
        """
        Return all the asts from the compilation unit

        Returns:
            Dict[str, Dict]: absolute path -> ast
        """
        return {
            source_unit.filename.absolute: source_unit.ast
            for source_unit in self.source_units.values()
        }

    def create_source_unit(self, filename: Filename) -> SourceUnit:
        """
        Create the source unit associated with the filename
        Add the relevant info in the compilation unit/crytic compile
        If the source unit already exist, return it
        Also appends filename to the end of filenames, if not already present
        So this function should be called in the order you want filenames to have

        Args:
            filename (Filename): filename of the source unit

        Returns:
            SourceUnit: the source unit
        """
        if filename not in self._source_units:
            source_unit = SourceUnit(self, filename)
            self._source_units[filename] = source_unit
            if filename not in self.filenames:
                self.filenames.append(filename)
        return self._source_units[filename]

    @property
    def implementation_addresses(self) -> set[str]:
        """Return the implementation addresses if the compilation unit is a proxy.

        Diamond proxies can have multiple implementation addresses.

        Returns:
            set[str]: Set of implementation addresses (empty if not a proxy)
        """
        return self._implementation_addresses

    @implementation_addresses.setter
    def implementation_addresses(self, implementations: set[str]) -> None:
        """Set the implementation addresses.

        Args:
            implementations: Set of implementation addresses
        """
        self._implementation_addresses = implementations

    # endregion
    ###################################################################################
    ###################################################################################
    # region Filenames
    ###################################################################################
    ###################################################################################

    @property
    def filenames(self) -> list[Filename]:
        """Return the filenames used by the compilation unit

        Returns:
            list[Filename]: Filenames used by the compilation units
        """
        return self._filenames

    @filenames.setter
    def filenames(self, all_filenames: list[Filename]) -> None:
        """Set the filenames

        Args:
            all_filenames (List[Filename]): new filenames
        """
        self._filenames = all_filenames

    @property
    def filenames_for_export(self) -> list[Filename]:
        """Return filenames in the correct order for export (matching source map indices).

        If source ID mapping is available (from Foundry/Hardhat build-info), returns
        filenames ordered by source ID. Otherwise, returns filenames in append order.

        Returns:
            list[Filename]: Filenames ordered for export
        """
        if not self._source_id_to_filename:
            return self._filenames

        # Build list indexed by source ID; +1 because IDs are zero-indexed
        max_id = max(self._source_id_to_filename.keys())
        size = max(max_id + 1, len(self._filenames))
        result: list[Filename | None] = [None] * size

        for source_id, filename in self._source_id_to_filename.items():
            result[source_id] = filename

        # Fill gaps with filenames from _filenames that aren't in the mapping
        mapped_filenames = set(self._source_id_to_filename.values())
        unmapped = [f for f in self._filenames if f not in mapped_filenames]
        unmapped_iter = iter(unmapped)

        for i, entry in enumerate(result):
            if entry is None:
                try:
                    result[i] = next(unmapped_iter)
                except StopIteration:
                    break

        # Gaps in the source ID sequence mean the build-info is incomplete;
        # exporting with shifted indices would silently produce wrong source maps
        gaps = [i for i, f in enumerate(result) if f is None]
        if gaps:
            raise ValueError(
                f"Source ID gaps at indices {gaps} — cannot produce correct sourceList. "
                f"This likely indicates missing sources in build-info."
            )

        return cast(list[Filename], result)

    def set_source_id(self, source_id: int, filename: Filename) -> None:
        """Set the source ID for a filename.

        This is used by Foundry/Hardhat parsers to maintain correct source map indices.

        Args:
            source_id (int): The source ID from the build-info
            filename (Filename): The filename associated with this ID
        """
        self._source_id_to_filename[source_id] = filename

    @property
    def filename_to_contracts(self) -> dict[Filename, set[str]]:
        """Return a dict mapping the filename to a list of contract declared

        Returns:
            Dict[Filename, List[str]]: Filename -> List[contract_name]
        """
        return self._filename_to_contracts

    def find_absolute_filename_from_used_filename(self, used_filename: str) -> str:
        """Return the absolute filename based on the used one

        Args:
            used_filename (str): Used filename

        Raises:
            ValueError: If the filename is not found

        Returns:
            str: Absolute filename
        """
        # Note: we could memoize this function if the third party end up using it heavily
        # If used_filename is already an absolute path no need to lookup
        if used_filename in self._crytic_compile.filenames:
            return used_filename
        d_file = {f.used: f.absolute for f in self._filenames}
        if used_filename not in d_file:
            raise ValueError("f{filename} does not exist in {d}")
        return d_file[used_filename]

    def relative_filename_from_absolute_filename(self, absolute_filename: str) -> str:
        """Return the relative file based on the absolute name

        Args:
            absolute_filename (str): Absolute filename

        Raises:
            ValueError: If the filename is not found

        Returns:
            str: Absolute filename
        """
        d_file = {f.absolute: f.relative for f in self._filenames}
        if absolute_filename not in d_file:
            raise ValueError("f{absolute_filename} does not exist in {d}")
        return d_file[absolute_filename]

    def filename_lookup(self, filename: str) -> Filename:
        """Return a crytic_compile.naming.Filename from a any filename

        Args:
            filename (str): filename (used/absolute/relative)

        Raises:
            ValueError: If the filename is not in the project

        Returns:
            Filename: Associated Filename object
        """
        from crytic_compile.platform.hardhat import Hardhat
        from crytic_compile.platform.truffle import Truffle

        if isinstance(self.crytic_compile.platform, Truffle) and filename.startswith("project:/"):
            filename = filename[len("project:/") :]

        if isinstance(self.crytic_compile.platform, Hardhat):
            # CASE 1 — npm/... → ...
            hh3_npm_path = re.match(r"npm/(.+?)@[^/]+/(.+)", filename)
            if hh3_npm_path:
                package = hh3_npm_path.group(1)
                rest = hh3_npm_path.group(2)
                filename = f"{package}/{rest}"

            # project/contracts/... → contracts/...
            hh3_contracts_path = re.match(r"project/contracts/(.+)", filename)
            if hh3_contracts_path:
                filename = f"contracts/{hh3_contracts_path.group(1)}"

        if self._filenames_lookup is None:
            self._filenames_lookup = {}
            for file in self._filenames:
                self._filenames_lookup[file.absolute] = file
                self._filenames_lookup[file.relative] = file
                self._filenames_lookup[file.used] = file
        if filename not in self._filenames_lookup:
            raise ValueError(
                f"{filename} does not exist in {[f.absolute for f in self._filenames_lookup.values()]}"
            )
        return self._filenames_lookup[filename]

    # endregion
    ###################################################################################
    ###################################################################################
    # region Compiler information
    ###################################################################################
    ###################################################################################

    @property
    def compiler_version(self) -> "CompilerVersion":
        """Return the compiler info

        Returns:
            CompilerVersion: compiler info
        """
        return self._compiler_version

    @compiler_version.setter
    def compiler_version(self, compiler: CompilerVersion) -> None:
        """Set the compiler version

        Args:
            compiler (CompilerVersion): New compiler version
        """
        self._compiler_version = compiler

    # endregion
    ###################################################################################
    ###################################################################################
